# Copyright (c) 2025, Owen d'ALMEIDA and Contributors
# See license.txt

# import frappe
import unittest

class TestDocumentLog(unittest.TestCase):
	pass
